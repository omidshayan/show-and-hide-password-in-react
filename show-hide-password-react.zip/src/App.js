import React, { useState } from 'react';
import { Icon } from 'react-icons-kit'
import {eye} from 'react-icons-kit/feather/eye';
import {eyeOff} from 'react-icons-kit/feather/eyeOff';


function App() {

const [hide, setShow] = useState(eyeOff)
const [type, setPassword] = useState("password")


const handleClick =() =>{
  if(type === 'password'){
    setPassword('text')
    setShow(eye)
  }else{
    setPassword('password')
    setShow(eyeOff)
  }
}
    
  return (
    <div className="container">
        <div className="input-item">
         
          <input type={type} />
          <span onClick={handleClick}><Icon icon={hide} size={25} /></span>
        </div>
    </div>
  );
}

export default App;
